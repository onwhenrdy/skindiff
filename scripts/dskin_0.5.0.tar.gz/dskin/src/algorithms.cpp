#include "algorithms.h"

namespace sc
{
    namespace algorithm
    {

    }
}
